<?php
class SkillMatcher {
    private $skill_database = [
        'html', 'css', 'javascript', 'php', 'python', 'java', 'mysql', 'react', 'react.js',
        'laravel', 'node.js', 'angular', 'angular.js', 'vue.js', 'django', 'git', 'docker',
        'aws', 'typescript', 'sql', 'mongodb', 'redux', 'graphql', '.net', 'rest apis',
        'spring', 'soap', 'scrum/agile', 'bootstrap', 'wordpress', 'web design', 'asp.net mvc',
        'asp.net', 'amazon web services', 'front-end development', 'web applications', 'jquery',
        'linux', 'apache', 'nginx', 'problem solving', 'cross-team communication', 'sql databases',
        'kentico', 'drupal'
    ];

    private $job_database = [
        [
            'title' => 'Frontend Developer',
            'skills' => ['html', 'css', 'javascript', 'react.js', 'typescript', 'angular.js', 'bootstrap', 'jquery', 'front-end development', 'web design'],
            'description' => 'Crafting immersive web interfaces with modern frameworks.',
            'company' => 'Nexlify',
            'salary' => '$90,000 - $130,000',
            'location' => 'Remote'
        ],
        [
            'title' => 'Backend Developer',
            'skills' => ['php', 'mysql', 'laravel', 'python', 'node.js', 'rest apis', 'soap', 'sql databases', 'apache', 'nginx'],
            'description' => 'Building robust server-side solutions and APIs.',
            'company' => 'CodeZap',
            'salary' => '$100,000 - $140,000',
            'location' => 'San Francisco, CA'
        ],
        [
            'title' => 'Full Stack Developer',
            'skills' => ['html', 'css', 'javascript', 'php', 'mysql', 'react.js', 'node.js', 'asp.net', 'asp.net mvc', 'sql databases', 'web applications'],
            'description' => 'Delivering end-to-end web applications with seamless integration.',
            'company' => 'TechTrend',
            'salary' => '$110,000 - $150,000',
            'location' => 'New York, NY'
        ],
        [
            'title' => 'DevOps Engineer',
            'skills' => ['docker', 'aws', 'git', 'python', 'scrum/agile', 'linux', 'apache', 'nginx', 'amazon web services'],
            'description' => 'Optimizing CI/CD pipelines and cloud infrastructure.',
            'company' => 'CloudPeak',
            'salary' => '$120,000 - $160,000',
            'location' => 'Remote'
        ],
        [
            'title' => 'Java Developer',
            'skills' => ['java', 'spring', 'rest apis', 'sql', 'scrum/agile', 'sql databases'],
            'description' => 'Developing enterprise-grade applications with Spring.',
            'company' => 'JavaCore',
            'salary' => '$95,000 - $135,000',
            'location' => 'Chicago, IL'
        ],
        [
            'title' => 'CMS Developer',
            'skills' => ['wordpress', 'drupal', 'kentico', 'php', 'javascript', 'html', 'css', 'web design'],
            'description' => 'Building and customizing content management systems.',
            'company' => 'ContentCraft',
            'salary' => '$85,000 - $125,000',
            'location' => 'Austin, TX'
        ]
    ];

    public function extractSkills($text) {
        $text_lower = strtolower($text);
        $skills_found = [];

        foreach ($this->skill_database as $skill) {
            $pattern = '/\b' . preg_quote($skill, '/') . '\b/i';
            $count = preg_match_all($pattern, $text, $matches);
            
            if ($count > 0) {
                $confidence = min(1.0, $count * 0.3 + 0.4);
                $skills_found[$skill] = [
                    'name' => $skill,
                    'confidence' => round($confidence, 2),
                    'count' => $count
                ];
            }
        }

        return $skills_found;
    }

    public function checkEligibility($extracted_skills, $required_skills) {
        $skill_names = array_keys($extracted_skills);
        $matching_skills = array_intersect($required_skills, $skill_names);
        $missing_skills = array_diff($required_skills, $skill_names);
        
        $match_percentage = count($required_skills) > 0 
            ? (count($matching_skills) / count($required_skills)) * 100 
            : 0;

        $is_eligible = count($matching_skills) === count($required_skills);

        return [
            'match_percentage' => round($match_percentage, 2),
            'matching_skills' => array_values($matching_skills),
            'missing_skills' => array_values($missing_skills),
            'is_eligible' => $is_eligible
        ];
    }

    public function matchJobs($extracted_skills) {
        $skill_names = array_keys($extracted_skills);
        $matches = [];

        foreach ($this->job_database as $job) {
            $matched_skills = array_intersect($job['skills'], $skill_names);
            $match_percentage = count($job['skills']) > 0 
                ? (count($matched_skills) / count($job['skills'])) * 100 
                : 0;

            if ($match_percentage >= 30) {
                $matches[] = [
                    'title' => $job['title'],
                    'description' => $job['description'],
                    'match_percentage' => round($match_percentage, 2),
                    'required_skills' => $job['skills'],
                    'matched_skills' => array_values($matched_skills),
                    'company' => $job['company'],
                    'salary' => $job['salary'],
                    'location' => $job['location']
                ];
            }
        }

        usort($matches, function($a, $b) {
            return $b['match_percentage'] <=> $a['match_percentage'];
        });

        return $matches;
    }
}
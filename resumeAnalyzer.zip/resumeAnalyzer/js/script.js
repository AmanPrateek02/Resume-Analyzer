document.addEventListener('DOMContentLoaded', () => {
    const navButtons = document.querySelectorAll('.nav-btn');
    const tabContents = document.querySelectorAll('.tab-content');
    const forms = document.querySelectorAll('form');
    const resultsSection = document.getElementById('results');
    const skillsInput = document.querySelector('textarea[name="required_skills"]');
    const suggestionsContainer = document.createElement('div');
    suggestionsContainer.classList.add('suggestions');

    // Skill suggestions list
    const availableSkills = [
        'html', 'css', 'javascript', 'php', 'python', 'java', 'mysql', 'react', 'react.js',
        'laravel', 'node.js', 'angular', 'angular.js', 'vue.js', 'django', 'git', 'docker',
        'aws', 'typescript', 'sql', 'mongodb', 'redux', 'graphql', '.net', 'rest apis',
        'spring', 'soap', 'scrum/agile', 'bootstrap', 'wordpress', 'web design', 'asp.net mvc',
        'asp.net', 'amazon web services', 'front-end development', 'web applications', 'jquery',
        'linux', 'apache', 'nginx', 'problem solving', 'cross-team communication', 'sql databases',
        'kentico', 'drupal'
    ];

    // Tab switching
    navButtons.forEach(button => {
        button.addEventListener('click', () => {
            navButtons.forEach(btn => {
                btn.classList.remove('active');
                btn.setAttribute('aria-selected', 'false');
            });
            tabContents.forEach(content => content.classList.remove('active'));

            button.classList.add('active');
            button.setAttribute('aria-selected', 'true');
            document.getElementById(button.dataset.tab).classList.add('active');
            resultsSection.classList.add('hidden');
        });
    });

    // Skill suggestions
    if (skillsInput) {
        skillsInput.parentElement.appendChild(suggestionsContainer);
        skillsInput.addEventListener('input', () => {
            const query = skillsInput.value.toLowerCase().split(',').pop().trim();
            suggestionsContainer.innerHTML = '';
            if (query) {
                const matches = availableSkills.filter(skill => skill.includes(query));
                matches.forEach(skill => {
                    const item = document.createElement('div');
                    item.classList.add('suggestion-item');
                    item.textContent = skill;
                    item.addEventListener('click', () => {
                        const currentSkills = skillsInput.value.split(',').slice(0, -1);
                        skillsInput.value = [...currentSkills, skill].join(', ') + ', ';
                        suggestionsContainer.style.display = 'none';
                        skillsInput.focus();
                    });
                    suggestionsContainer.appendChild(item);
                });
                suggestionsContainer.style.display = matches.length ? 'block' : 'none';
            } else {
                suggestionsContainer.style.display = 'none';
            }
        });

        document.addEventListener('click', (e) => {
            if (!skillsInput.contains(e.target) && !suggestionsContainer.contains(e.target)) {
                suggestionsContainer.style.display = 'none';
            }
        });
    }

    // Form submission with progress tracker
    forms.forEach(form => {
        form.addEventListener('submit', async (e) => {
            e.preventDefault();

            // Initialize progress tracker
            resultsSection.innerHTML = `
                <div class="progress-tracker">
                    <div class="progress-step active">
                        <div class="step-circle">1</div>
                        <div class="step-label">Uploading</div>
                    </div>
                    <div class="progress-step">
                        <div class="step-circle">2</div>
                        <div class="step-label">Parsing</div>
                    </div>
                    <div class="progress-step">
                        <div class="step-circle">3</div>
                        <div class="step-label">Analyzing</div>
                    </div>
                </div>
                <div class="loader">Uploading your resume...</div>
            `;
            resultsSection.classList.remove('hidden');

            const formData = new FormData(form);

            try {
                // Simulate progress
                setTimeout(() => {
                    document.querySelectorAll('.progress-step')[1].classList.add('active');
                    document.querySelector('.loader').textContent = 'Parsing PDF...';
                }, 1000);
                setTimeout(() => {
                    document.querySelectorAll('.progress-step')[2].classList.add('active');
                    document.querySelector('.loader').textContent = 'Analyzing skills...';
                }, 2000);

                const response = await fetch('process.php', {
                    method: 'POST',
                    body: formData
                });

                const text = await response.text();
                console.log('Raw response:', text);

                let data;
                try {
                    data = JSON.parse(text);
                } catch (jsonError) {
                    throw new Error('Invalid JSON response: ' + jsonError.message);
                }

                if (!data.success) {
                    throw new Error(data.error || 'Unknown error occurred');
                }

                let html = '<h2>Analysis Results</h2>';

                // Skills
                html += '<h3>Extracted Skills</h3>';
                html += '<div class="skill-grid">';
                for (const [skill, info] of Object.entries(data.extracted_skills)) {
                    html += `
                        <div class="skill-card">
                            <strong>${skill}</strong>
                            <span>Confidence: ${info.confidence * 100}%</span>
                            <div class="confidence-bar">
                                <div class="confidence-fill" style="width: ${info.confidence * 100}%"></div>
                            </div>
                            <span>Mentions: ${info.count}</span>
                        </div>`;
                }
                html += '</div>';

                // Eligibility
                if (data.eligibility) {
                    html += '<h3>Eligibility Analysis</h3>';
                    html += `<div class="eligibility ${data.eligibility.is_eligible ? 'eligible' : 'not-eligible'}">`;
                    html += `<p><strong>${data.eligibility.is_eligible ? '✅ Eligible!' : '❌ Not Eligible'}</strong></p>`;
                    if (!data.eligibility.is_eligible && data.eligibility.missing_skills.length) {
                        html += `<p>Missing skill${data.eligibility.missing_skills.length > 1 ? 's' : ''}.</p>`;
                    }
                    html += `<p>Match: ${data.eligibility.match_percentage}%</p>`;
                    html += `<div class="match-bar"><div class="match-fill" style="width: ${data.eligibility.match_percentage}%"></div></div>`;

                    if (data.eligibility.matching_skills.length) {
                        html += '<p>Matching Skills:</p><div class="skill-grid">';
                        data.eligibility.matching_skills.forEach(skill => {
                            html += `<div class="skill-card">${skill}</div>`;
                        });
                        html += '</div>';
                    }

                    if (data.eligibility.missing_skills.length) {
                        html += '<p>Missing Skills:</p><div class="skill-grid">';
                        data.eligibility.missing_skills.forEach(skill => {
                            html += `<div class="skill-card">${skill}</div>`;
                        });
                        html += '</div>';
                    }
                    html += '</div>';
                }

                // Job Matches
                if (data.job_matches.length) {
                    html += '<h3>Recommended Jobs</h3>';
                    html += '<div class="job-grid">';
                    data.job_matches.forEach(job => {
                        html += `
                            <div class="job-card">
                                <h4>${job.title}</h4>
                                <p>${job.description}</p>
                                <p>Match: ${job.match_percentage}%</p>
                                <div class="match-bar">
                                    <div class="match-fill" style="width: ${job.match_percentage}%"></div>
                                </div>
                                <p>Skills: ${job.matched_skills.join(', ')}</p>
                                <p>Company: ${job.company}</p>
                                <p>Salary: ${job.salary}</p>
                                <p>Location: ${job.location}</p>
                                <button class="apply-btn" onclick="alert('Apply is a demo!')">Apply Now</button>
                            </div>`;
                    });
                    html += '</div>';
                }

                resultsSection.innerHTML = html;

            } catch (error) {
                resultsSection.innerHTML = `
                    <h2>Error</h2>
                    <p class="error">Failed to process: ${error.message}</p>
                    <p>Please check:</p>
                    <ul>
                        <li>PDF has selectable text</li>
                        <li>File is under 5MB</li>
                        <li>Try again later</li>
                    </ul>`;
                console.error('Error:', error);
            }
        });
    });
});